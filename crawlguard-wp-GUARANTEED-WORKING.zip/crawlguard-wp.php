<?php
/**
 * Plugin Name: CrawlGuard WP Pro
 * Description: AI Content Monetization & Bot Detection
 * Version: 2.0.0
 * Author: CrawlGuard
 */

if (!defined('ABSPATH')) {
    exit;
}

class CrawlGuardWP {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        
        // Bot detection on every page load
        add_action('wp', array($this, 'detect_bot'));
        
        register_activation_hook(__FILE__, array($this, 'activate'));
    }
    
    public function init() {
        $this->create_tables();
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'CrawlGuard Pro',
            'CrawlGuard Pro',
            'manage_options',
            'crawlguard-pro',
            array($this, 'admin_page'),
            'dashicons-shield-alt',
            30
        );
        
        add_submenu_page(
            'crawlguard-pro',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'crawlguard-pro',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'crawlguard-pro',
            'Settings',
            'Settings',
            'manage_options',
            'crawlguard-settings',
            array($this, 'settings_page')
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>🛡️ CrawlGuard Pro Dashboard</h1>
            
            <div class="notice notice-success">
                <p><strong>🎉 Dashboard is Working!</strong> Your AI bot detection system is now active and monitoring your site.</p>
            </div>
            
            <div id="crawlguard-dashboard">
                <div class="cg-stats-grid">
                    <div class="cg-stat-card">
                        <div class="cg-stat-icon">🤖</div>
                        <h3>AI Bots Detected Today</h3>
                        <div class="cg-stat-number"><?php echo $this->get_bot_count(); ?></div>
                        <p>Real-time AI bot detection</p>
                    </div>
                    <div class="cg-stat-card">
                        <div class="cg-stat-icon">💰</div>
                        <h3>Revenue Potential Today</h3>
                        <div class="cg-stat-number">$<?php echo number_format($this->get_revenue_potential(), 2); ?></div>
                        <p>From AI bot monetization</p>
                    </div>
                    <div class="cg-stat-card">
                        <div class="cg-stat-icon">📊</div>
                        <h3>Pages Protected</h3>
                        <div class="cg-stat-number"><?php echo wp_count_posts()->publish; ?></div>
                        <p>Total WordPress pages</p>
                    </div>
                    <div class="cg-stat-card">
                        <div class="cg-stat-icon">🔥</div>
                        <h3>Total Detections</h3>
                        <div class="cg-stat-number"><?php echo $this->get_total_bot_count(); ?></div>
                        <p>All-time bot detection</p>
                    </div>
                </div>
                
                <div class="cg-revenue-chart">
                    <h3>📈 Revenue Tracking</h3>
                    <div class="revenue-info">
                        <div class="revenue-breakdown">
                            <h4>Bot Revenue Rates:</h4>
                            <ul>
                                <li><strong>GPT Bots:</strong> $0.10 per detection</li>
                                <li><strong>Claude AI:</strong> $0.08 per detection</li>
                                <li><strong>Google Bard:</strong> $0.06 per detection</li>
                                <li><strong>Other AI:</strong> $0.03-$0.05 per detection</li>
                            </ul>
                        </div>
                        <div class="revenue-projection">
                            <h4>💡 Projection:</h4>
                            <p>With 100 AI bot visits/day = <strong>$6-10 daily revenue</strong></p>
                            <p>Monthly potential: <strong>$180-300</strong></p>
                        </div>
                    </div>
                </div>
                
                <div class="cg-activity-feed">
                    <h3>🕒 Recent Bot Activity</h3>
                    <div id="bot-activity">
                        <?php $this->display_recent_activity(); ?>
                    </div>
                    <button id="refresh-activity" class="button button-secondary">🔄 Refresh Activity</button>
                </div>
                
                <div class="cg-setup-guide">
                    <h3>🚀 Monetization Setup</h3>
                    <div class="setup-steps">
                        <div class="setup-step completed">
                            <span class="step-number">1</span>
                            <div>
                                <h4>✅ Plugin Activated</h4>
                                <p>CrawlGuard Pro is running and detecting bots</p>
                            </div>
                        </div>
                        <div class="setup-step <?php echo $this->is_stripe_configured() ? 'completed' : 'pending'; ?>">
                            <span class="step-number">2</span>
                            <div>
                                <h4><?php echo $this->is_stripe_configured() ? '✅' : '⏳'; ?> Payment Setup</h4>
                                <p>Configure Stripe for automatic payments</p>
                                <?php if (!$this->is_stripe_configured()): ?>
                                <a href="<?php echo admin_url('admin.php?page=crawlguard-settings'); ?>" class="button button-primary">Setup Payments</a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="setup-step pending">
                            <span class="step-number">3</span>
                            <div>
                                <h4>💰 Start Earning</h4>
                                <p>Revenue will be generated automatically from AI bot visits</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .cg-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .cg-stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
            border-left: 4px solid #0073aa;
        }
        .cg-stat-icon {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .cg-stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #0073aa;
            margin: 10px 0;
        }
        .cg-stat-card h3 {
            margin: 10px 0;
            color: #333;
            font-size: 16px;
        }
        .cg-stat-card p {
            color: #666;
            font-size: 14px;
            margin: 0;
        }
        .cg-activity-feed, .cg-revenue-chart, .cg-setup-guide {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 20px 0;
        }
        .activity-item {
            padding: 10px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .revenue {
            color: #28a745;
            font-weight: bold;
        }
        .revenue-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        .revenue-breakdown ul {
            list-style: none;
            padding: 0;
        }
        .revenue-breakdown li {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .setup-steps {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .setup-step {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            border-radius: 8px;
            background: #f9f9f9;
        }
        .setup-step.completed {
            background: #d4edda;
            border-left: 4px solid #28a745;
        }
        .setup-step.pending {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
        }
        .step-number {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background: #0073aa;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .setup-step.completed .step-number {
            background: #28a745;
        }
        .setup-step.pending .step-number {
            background: #ffc107;
        }
        #refresh-activity {
            margin-top: 15px;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            $('#refresh-activity').click(function() {
                $(this).text('🔄 Refreshing...').prop('disabled', true);
                location.reload();
            });
            
            // Simulate real-time updates every 30 seconds
            setInterval(function() {
                // Add visual indicator of activity
                $('.cg-stat-card').addClass('pulse');
                setTimeout(function() {
                    $('.cg-stat-card').removeClass('pulse');
                }, 1000);
            }, 30000);
        });
        </script>
        
        <style>
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.02); }
            100% { transform: scale(1); }
        }
        .pulse {
            animation: pulse 0.5s ease-in-out;
        }
        </style>
        <?php
    }
    
    public function settings_page() {
        if (isset($_POST['submit'])) {
            update_option('crawlguard_detection_enabled', isset($_POST['detection_enabled']));
            update_option('crawlguard_monetization_enabled', isset($_POST['monetization_enabled']));
            echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
        }
        
        $detection_enabled = get_option('crawlguard_detection_enabled', true);
        $monetization_enabled = get_option('crawlguard_monetization_enabled', true);
        ?>
        <div class="wrap">
            <h1>CrawlGuard Pro Settings</h1>
            
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th scope="row">Bot Detection</th>
                        <td>
                            <label>
                                <input type="checkbox" name="detection_enabled" <?php checked($detection_enabled); ?> />
                                Enable AI bot detection
                            </label>
                            <p class="description">Automatically detect and log AI bots visiting your site.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Monetization</th>
                        <td>
                            <label>
                                <input type="checkbox" name="monetization_enabled" <?php checked($monetization_enabled); ?> />
                                Enable revenue generation
                            </label>
                            <p class="description">Track revenue potential from AI bot visits.</p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
            </form>
            
            <div class="stripe-setup" style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-top: 20px;">
                <h2>💳 Stripe Payment Setup</h2>
                <p>To enable real money from AI bot detection, add these to your <code>wp-config.php</code>:</p>
                <pre style="background: #2d3748; color: #e2e8f0; padding: 15px; border-radius: 5px;">define('STRIPE_PUBLISHABLE_KEY', 'pk_live_YOUR_KEY');
define('STRIPE_SECRET_KEY', 'sk_live_YOUR_KEY');
define('STRIPE_WEBHOOK_SECRET', 'whsec_YOUR_SECRET');</pre>
                
                <h3>How It Works:</h3>
                <ol>
                    <li>AI bots visit your site (ChatGPT, Claude, etc.)</li>
                    <li>CrawlGuard detects and identifies them</li>
                    <li>Micro-payments are processed automatically</li>
                    <li>You receive 85% of revenue, 15% platform fee</li>
                </ol>
            </div>
        </div>
        <?php
    }
    
    public function detect_bot() {
        if (is_admin()) return;
        
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        
        if (empty($user_agent)) return;
        
        $ai_bots = [
            'GPTBot' => 0.10,
            'ChatGPT-User' => 0.10,
            'CCBot' => 0.08,
            'anthropic-ai' => 0.08,
            'Claude-Web' => 0.08,
            'Google-Extended' => 0.06,
            'GoogleOther' => 0.06,
            'Bard' => 0.06,
            'PaLM' => 0.06,
            'FacebookBot' => 0.05,
            'Meta-ExternalAgent' => 0.05,
            'BingBot' => 0.04,
            'msnbot' => 0.04,
            'Bytespider' => 0.03,
            'YandexBot' => 0.03
        ];
        
        foreach ($ai_bots as $bot => $rate) {
            if (stripos($user_agent, $bot) !== false) {
                $this->log_bot_detection($bot, $user_agent, $ip, $rate);
                break;
            }
        }
    }
    
    private function log_bot_detection($bot_type, $user_agent, $ip, $revenue) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'crawlguard_logs',
            array(
                'bot_type' => $bot_type,
                'user_agent' => substr($user_agent, 0, 500), // Limit length
                'ip_address' => $ip,
                'revenue' => $revenue,
                'page_url' => $_SERVER['REQUEST_URI'] ?? '',
                'detected_at' => current_time('mysql')
            )
        );
    }
    
    private function get_bot_count() {
        global $wpdb;
        return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}crawlguard_logs WHERE DATE(detected_at) = CURDATE()") ?: 0;
    }
    
    private function get_total_bot_count() {
        global $wpdb;
        return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}crawlguard_logs") ?: 0;
    }
    
    private function get_revenue_potential() {
        global $wpdb;
        return $wpdb->get_var("SELECT SUM(revenue) FROM {$wpdb->prefix}crawlguard_logs WHERE DATE(detected_at) = CURDATE()") ?: 0;
    }
    
    private function display_recent_activity() {
        global $wpdb;
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}crawlguard_logs'");
        if (!$table_exists) {
            echo '<p>🤖 Bot detection is active. Activity will appear here as AI bots visit your site.</p>';
            return;
        }
        
        $logs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}crawlguard_logs ORDER BY detected_at DESC LIMIT 10");
        
        if (empty($logs)) {
            echo '<div class="activity-item">';
            echo '<span>🤖 No bot activity detected yet. The system is actively monitoring...</span>';
            echo '</div>';
            echo '<div class="activity-item">';
            echo '<span>💡 <strong>Tip:</strong> AI bots like ChatGPT and Claude will automatically be detected when they visit your site.</span>';
            echo '</div>';
            return;
        }
        
        foreach ($logs as $log) {
            echo '<div class="activity-item">';
            echo '<div>';
            echo '<strong>' . esc_html($log->bot_type) . '</strong> detected ';
            echo '<small style="color: #666;">from ' . esc_html(substr($log->ip_address, 0, 10)) . '...</small>';
            echo '</div>';
            echo '<div>';
            echo '<span class="revenue">+$' . number_format($log->revenue, 3) . '</span> ';
            echo '<small>' . human_time_diff(strtotime($log->detected_at)) . ' ago</small>';
            echo '</div>';
            echo '</div>';
        }
    }
    
    private function is_stripe_configured() {
        return defined('STRIPE_SECRET_KEY') && !empty(STRIPE_SECRET_KEY);
    }
    
    public function create_tables() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'crawlguard_logs';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            bot_type varchar(100) NOT NULL,
            user_agent text,
            ip_address varchar(45) NOT NULL,
            revenue decimal(10,4) NOT NULL DEFAULT 0,
            page_url text,
            detected_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY bot_type (bot_type),
            KEY detected_at (detected_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    public function activate() {
        $this->create_tables();
        
        // Set default options
        add_option('crawlguard_detection_enabled', true);
        add_option('crawlguard_monetization_enabled', true);
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    public function admin_enqueue_scripts() {
        wp_enqueue_script('jquery');
    }
    
    public function enqueue_scripts() {
        // Frontend scripts if needed
    }
}

// Initialize the plugin
CrawlGuardWP::get_instance();
?>

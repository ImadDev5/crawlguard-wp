<?php
/**
 * Plugin Name: PayPerCrawl
 * Plugin URI: https://paypercrawl.com
 * Description: Turn AI bot traffic into revenue. Free beta - you keep 100% earnings!
 * Version: 1.0.0-beta
 * Author: PayPerCrawl
 * Author URI: https://paypercrawl.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: paypercrawl
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 * 
 * @package PayPerCrawl
 * @version 1.0.0-beta
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('PAYPERCRAWL_VERSION', '1.0.0-beta');
define('PAYPERCRAWL_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('PAYPERCRAWL_PLUGIN_URL', plugin_dir_url(__FILE__));
define('PAYPERCRAWL_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main PayPerCrawl Plugin Class
 */
class PayPerCrawl {
    
    /**
     * Plugin instance
     */
    private static $instance = null;
    
    /**
     * Get plugin instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize plugin
     */
    private function init() {
        // Setup autoloader
        spl_autoload_register(array($this, 'autoload'));
        
        // Hook into WordPress
        add_action('init', array($this, 'setup'));
        add_action('wp', array($this, 'detect_bots'));
        
        // Admin hooks
        if (is_admin()) {
            add_action('admin_menu', array($this, 'admin_menu'));
            add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
            add_action('wp_ajax_crawlguard_get_analytics', array($this, 'ajax_get_analytics'));
        }
        
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Simple autoloader
     */
    public function autoload($class_name) {
        // Only load our classes
        if (strpos($class_name, 'PayPerCrawl_') !== 0) {
            return;
        }
        
        // Convert class name to file name
        $file_name = 'class-' . strtolower(str_replace('_', '-', substr($class_name, 12))) . '.php';
        $file_path = PAYPERCRAWL_PLUGIN_DIR . 'includes/' . $file_name;
        
        if (file_exists($file_path)) {
            require_once $file_path;
        }
    }
    
    /**
     * Setup plugin components
     */
    public function setup() {
        // Initialize components
        if (class_exists('PayPerCrawl_DB')) {
            PayPerCrawl_DB::get_instance();
        }
        
        if (class_exists('PayPerCrawl_Detector')) {
            PayPerCrawl_Detector::get_instance();
        }
        
        if (class_exists('PayPerCrawl_Analytics')) {
            PayPerCrawl_Analytics::get_instance();
        }
    }
    
    /**
     * Bot detection on every page load
     */
    public function detect_bots() {
        if (class_exists('PayPerCrawl_Detector')) {
            $detector = PayPerCrawl_Detector::get_instance();
            $detection = $detector->detect();
            
            if ($detection) {
                // Log the detection
                if (class_exists('PayPerCrawl_DB')) {
                    PayPerCrawl_DB::get_instance()->log_detection($detection);
                }
                
                // Take action based on settings
                $action = get_option('paypercrawl_bot_action', 'allow');
                if ($action === 'block') {
                    status_header(403);
                    exit('Access Denied');
                }
            }
        }
    }
    
    /**
     * Add admin menu
     */
    public function admin_menu() {
        add_menu_page(
            'PayPerCrawl',
            'PayPerCrawl',
            'manage_options',
            'paypercrawl',
            array($this, 'dashboard_page'),
            'dashicons-shield-alt',
            30
        );
        
        add_submenu_page(
            'paypercrawl',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'paypercrawl',
            array($this, 'dashboard_page')
        );
        
        add_submenu_page(
            'paypercrawl',
            'Analytics',
            'Analytics',
            'manage_options',
            'paypercrawl-analytics',
            array($this, 'analytics_page')
        );
        
        add_submenu_page(
            'paypercrawl',
            'Settings',
            'Settings',
            'manage_options',
            'paypercrawl-settings',
            array($this, 'settings_page')
        );
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function admin_scripts($hook) {
        if (strpos($hook, 'paypercrawl') === false) {
            return;
        }
        
        wp_enqueue_style(
            'paypercrawl-admin',
            PAYPERCRAWL_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            PAYPERCRAWL_VERSION
        );
        
        wp_enqueue_script(
            'paypercrawl-admin',
            PAYPERCRAWL_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery', 'chart-js'),
            PAYPERCRAWL_VERSION,
            true
        );
        
        // Add Chart.js
        wp_enqueue_script(
            'chart-js',
            'https://cdn.jsdelivr.net/npm/chart.js',
            array(),
            '4.4.0',
            true
        );
        
        // Localize script for AJAX
        wp_localize_script('paypercrawl-admin', 'paypercrawl_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('paypercrawl_nonce')
        ));
    }
    
    /**
     * Dashboard page
     */
    public function dashboard_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        include PAYPERCRAWL_PLUGIN_DIR . 'templates/dashboard.php';
    }
    
    /**
     * Analytics page
     */
    public function analytics_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        include PAYPERCRAWL_PLUGIN_DIR . 'templates/analytics.php';
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        // Handle form submission
        if (isset($_POST['submit']) && wp_verify_nonce($_POST['paypercrawl_nonce'], 'paypercrawl_settings')) {
            update_option('paypercrawl_api_key', sanitize_text_field($_POST['api_key']));
            update_option('paypercrawl_worker_url', esc_url_raw($_POST['worker_url']));
            update_option('paypercrawl_bot_action', sanitize_text_field($_POST['bot_action']));
            update_option('paypercrawl_js_detection', isset($_POST['js_detection']) ? '1' : '0');
            
            echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
        }
        
        include PAYPERCRAWL_PLUGIN_DIR . 'templates/settings.php';
    }
    
    /**
     * AJAX handler for analytics
     */
    public function ajax_get_analytics() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'paypercrawl_nonce')) {
            wp_die('Security check failed');
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        if (class_exists('PayPerCrawl_Analytics')) {
            $analytics = PayPerCrawl_Analytics::get_instance();
            $data = $analytics->get_chart_data();
            wp_send_json_success($data);
        }
        
        wp_send_json_error('Analytics not available');
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        if (class_exists('PayPerCrawl_DB')) {
            PayPerCrawl_DB::get_instance()->create_tables();
        }
        
        // Set default options
        add_option('paypercrawl_bot_action', 'allow');
        add_option('paypercrawl_js_detection', '0');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up if needed
        flush_rewrite_rules();
    }
    
    /**
     * Check for missing credentials
     */
    public function audit_credentials() {
        $needed = array('paypercrawl_api_key', 'paypercrawl_worker_url');
        $missing = array();
        
        foreach ($needed as $key) {
            if (!get_option($key)) {
                $missing[] = $key;
            }
        }
        
        return $missing;
    }
}

// Initialize the plugin
PayPerCrawl::get_instance();

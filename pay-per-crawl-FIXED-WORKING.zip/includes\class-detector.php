<?php
/**
 * Bot Detection Engine
 * 
 * @package PayPerCrawl
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class PayPerCrawl_Detector {
    
    /**
     * Instance
     */
    private static $instance = null;
    
    /**
     * Bot signatures
     */
    private $bot_signatures = array();
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_bot_signatures();
    }
    
    /**
     * Load bot signatures
     */
    private function load_bot_signatures() {
        $this->bot_signatures = array(
            // AI Bots (High Value)
            'gptbot' => array('company' => 'OpenAI', 'confidence' => 95),
            'chatgpt-user' => array('company' => 'OpenAI', 'confidence' => 95),
            'ccbot' => array('company' => 'Anthropic', 'confidence' => 95),
            'claudebot' => array('company' => 'Anthropic', 'confidence' => 95),
            'google-extended' => array('company' => 'Google', 'confidence' => 90),
            'bard' => array('company' => 'Google', 'confidence' => 90),
            'bingbot' => array('company' => 'Microsoft', 'confidence' => 85),
            'facebookbot' => array('company' => 'Meta', 'confidence' => 85),
            
            // Other Common Bots
            'googlebot' => array('company' => 'Google', 'confidence' => 80),
            'slurp' => array('company' => 'Yahoo', 'confidence' => 75),
            'duckduckbot' => array('company' => 'DuckDuckGo', 'confidence' => 75),
            'twitterbot' => array('company' => 'Twitter', 'confidence' => 70),
            'linkedinbot' => array('company' => 'LinkedIn', 'confidence' => 70),
            'whatsapp' => array('company' => 'WhatsApp', 'confidence' => 70),
            
            // Research/Academic Bots
            'ia_archiver' => array('company' => 'Internet Archive', 'confidence' => 60),
            'archive.org_bot' => array('company' => 'Internet Archive', 'confidence' => 60),
            'researchbot' => array('company' => 'Research', 'confidence' => 50),
            'academicbot' => array('company' => 'Academic', 'confidence' => 50),
        );
    }
    
    /**
     * Main detection method
     */
    public function detect() {
        // Get request data
        $user_agent = $this->get_user_agent();
        $ip = $this->get_client_ip();
        $url = $this->get_current_url();
        
        // Skip admin and login pages
        if (is_admin() || strpos($url, 'wp-login') !== false) {
            return false;
        }
        
        // Check if already detected by Cloudflare Worker
        if (isset($_SERVER['HTTP_X_PPC_DETECTED']) && $_SERVER['HTTP_X_PPC_DETECTED'] === 'true') {
            return array(
                'bot' => 'CloudflareDetected',
                'company' => 'Edge Detection',
                'confidence' => 95,
                'ip' => $ip,
                'user_agent' => $user_agent,
                'url' => $url,
                'action' => 'logged'
            );
        }
        
        // PHP-based detection
        $detection = $this->detect_from_user_agent($user_agent);
        
        if ($detection) {
            $detection['ip'] = $ip;
            $detection['user_agent'] = $user_agent;
            $detection['url'] = $url;
            $detection['action'] = 'logged';
            
            return $detection;
        }
        
        // Advanced detection (optional)
        if (get_option('paypercrawl_js_detection') === '1') {
            $js_detection = $this->detect_with_js();
            if ($js_detection) {
                return $js_detection;
            }
        }
        
        return false;
    }
    
    /**
     * Detect bot from user agent
     */
    private function detect_from_user_agent($user_agent) {
        $user_agent_lower = strtolower($user_agent);
        
        foreach ($this->bot_signatures as $bot_pattern => $info) {
            if (strpos($user_agent_lower, $bot_pattern) !== false) {
                return array(
                    'bot' => $bot_pattern,
                    'company' => $info['company'],
                    'confidence' => $info['confidence']
                );
            }
        }
        
        // Generic bot patterns
        $generic_patterns = array('bot', 'crawler', 'spider', 'scraper', 'crawl');
        
        foreach ($generic_patterns as $pattern) {
            if (strpos($user_agent_lower, $pattern) !== false) {
                return array(
                    'bot' => 'GenericBot',
                    'company' => 'Unknown',
                    'confidence' => 30
                );
            }
        }
        
        return false;
    }
    
    /**
     * JS-based detection (stub for future)
     */
    private function detect_with_js() {
        // This would implement JavaScript challenge detection
        // For now, return false
        return false;
    }
    
    /**
     * Get user agent
     */
    private function get_user_agent() {
        return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    }
    
    /**
     * Get client IP
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_CF_CONNECTING_IP', 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
    
    /**
     * Get current URL
     */
    private function get_current_url() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
        $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
        
        return $protocol . '://' . $host . $uri;
    }
    
    /**
     * Get bot signatures for display
     */
    public function get_bot_signatures() {
        return $this->bot_signatures;
    }
    
    /**
     * Rate limiting check
     */
    private function check_rate_limit($ip) {
        $transient_key = 'paypercrawl_rate_' . md5($ip);
        $requests = get_transient($transient_key);
        
        if ($requests === false) {
            $requests = 1;
        } else {
            $requests++;
        }
        
        set_transient($transient_key, $requests, 60); // 1 minute window
        
        // If more than 10 requests per minute, it's likely a bot
        if ($requests > 10) {
            return array(
                'bot' => 'RapidRequests',
                'company' => 'Rate Limited',
                'confidence' => 80
            );
        }
        
        return false;
    }
}

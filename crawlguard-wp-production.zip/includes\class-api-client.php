<?php

if (!defined('ABSPATH')) {
    exit;
}

class CrawlGuard_API_Client {
    
    private $api_base_url = 'https://crawlguard-api-prod.crawlguard-api.workers.dev/v1';
    private $api_key;
    private $timeout = 5;
    private $site_id;
    
    public function __construct() {
        $options = get_option('crawlguard_options');
        $this->api_key = $options['api_key'] ?? 'cg_prod_9c4j1kwQaabRvYu2owwh6fLyGffOty1zx';
        $this->site_id = $options['site_id'] ?? 'site_oUSRqI213k8E';
        
        if (isset($options['api_url']) && !empty($options['api_url'])) {
            $this->api_base_url = rtrim($options['api_url'], '/');
            // Ensure /v1 is appended if not present
            if (!str_ends_with($this->api_base_url, '/v1')) {
                $this->api_base_url .= '/v1';
            }
        }
    }
    
    public function send_monetization_request($request_data) {
        if (empty($this->api_key)) {
            error_log('CrawlGuard: No API key configured');
            return array('success' => false, 'message' => 'No API key configured');
        }
        
        // Add required fields
        $request_data['site_id'] = $this->site_id;
        $request_data['timestamp'] = time();
        
        $response = wp_remote_post($this->api_base_url . '/monetize', array(
            'body' => json_encode($request_data),
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => 'CrawlGuard-WP/' . (defined('CRAWLGUARD_VERSION') ? CRAWLGUARD_VERSION : '1.0.0')
            ),
            'timeout' => $this->timeout,
            'blocking' => true // Changed to true to get response
        ));
        
        if (is_wp_error($response)) {
            error_log('CrawlGuard API Error: ' . $response->get_error_message());
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code === 200) {
            $data = json_decode($body, true);
            return array('success' => true, 'data' => $data);
        } else {
            error_log('CrawlGuard API Error: Status ' . $status_code . ' - ' . $body);
            return array('success' => false, 'message' => 'API error: ' . $status_code);
        }
    }
    
    public function test_connection() {
        $response = wp_remote_get($this->api_base_url . '/status', array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'User-Agent' => 'CrawlGuard-WP/' . (defined('CRAWLGUARD_VERSION') ? CRAWLGUARD_VERSION : '1.0.0')
            ),
            'timeout' => $this->timeout,
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Connection failed: ' . $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code === 200) {
            $data = json_decode($body, true);
            if ($data && isset($data['status'])) {
                return array(
                    'success' => true,
                    'message' => 'Connection successful - API is healthy',
                    'data' => $data
                );
            } else {
                return array(
                    'success' => false,
                    'message' => 'Invalid API response format'
                );
            }
        } else {
            return array(
                'success' => false,
                'message' => 'API returned status code: ' . $status_code . ' - ' . $body
            );
        }
    }
    
    public function register_site() {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'message' => 'API key is required'
            );
        }
        
        $site_data = array(
            'site_url' => home_url(),
            'admin_email' => get_option('admin_email'),
            'site_name' => get_bloginfo('name'),
            'wordpress_version' => get_bloginfo('version'),
            'plugin_version' => defined('CRAWLGUARD_VERSION') ? CRAWLGUARD_VERSION : '1.0.0',
            'php_version' => PHP_VERSION,
            'timestamp' => time()
        );
        
        $response = wp_remote_post($this->api_base_url . '/sites/register', array(
            'body' => json_encode($site_data),
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => 'CrawlGuard-WP/' . (defined('CRAWLGUARD_VERSION') ? CRAWLGUARD_VERSION : '1.0.0')
            ),
            'timeout' => 10, // Longer timeout for registration
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Registration failed: ' . $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code === 200) {
            $data = json_decode($body, true);
            if ($data && isset($data['success']) && $data['success']) {
                return array(
                    'success' => true,
                    'message' => 'Site registered successfully',
                    'data' => $data
                );
            } else {
                return array(
                    'success' => false,
                    'message' => 'Registration response invalid: ' . $body
                );
            }
        } else {
            return array(
                'success' => false,
                'message' => 'Registration failed with status code: ' . $status_code,
                'body' => $body
            );
        }
    }
    
    public function get_analytics($timeframe = '24h') {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'message' => 'API key is required'
            );
        }
        
        $query_params = array(
            'site_id' => $this->site_id,
            'timeframe' => $timeframe
        );
        
        $response = wp_remote_get($this->api_base_url . '/analytics?' . http_build_query($query_params), array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => 'CrawlGuard-WP/' . (defined('CRAWLGUARD_VERSION') ? CRAWLGUARD_VERSION : '1.0.0')
            ),
            'timeout' => $this->timeout,
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Analytics request failed: ' . $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code === 200) {
            $data = json_decode($body, true);
            if ($data) {
                return array(
                    'success' => true,
                    'data' => $data
                );
            } else {
                return array(
                    'success' => false,
                    'message' => 'Invalid analytics response format'
                );
            }
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch analytics: ' . $status_code . ' - ' . $body
            );
        }
    }
    
    public function send_bot_detection($detection_data) {
        if (empty($this->api_key)) {
            error_log('CrawlGuard: No API key configured for bot detection');
            return array('success' => false, 'message' => 'No API key configured');
        }
        
        // Add required fields
        $detection_data['site_id'] = $this->site_id;
        $detection_data['timestamp'] = time();
        
        $response = wp_remote_post($this->api_base_url . '/detect', array(
            'body' => json_encode($detection_data),
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => 'CrawlGuard-WP/' . (defined('CRAWLGUARD_VERSION') ? CRAWLGUARD_VERSION : '1.0.0')
            ),
            'timeout' => $this->timeout,
            'blocking' => true, // Changed to true to get response
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            error_log('CrawlGuard Bot Detection API Error: ' . $response->get_error_message());
            return array('success' => false, 'message' => $response->get_error_message());
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code === 200) {
            $data = json_decode($body, true);
            if ($data) {
                return array('success' => true, 'data' => $data);
            } else {
                return array('success' => false, 'message' => 'Invalid detection response');
            }
        } else {
            error_log('CrawlGuard Bot Detection Error: Status ' . $status_code . ' - ' . $body);
            return array('success' => false, 'message' => 'Detection API error: ' . $status_code);
        }
    }
    
    public function get_site_info() {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'message' => 'API key is required'
            );
        }
        
        $response = wp_remote_get($this->api_base_url . '/sites/info?' . http_build_query(array(
            'site_url' => home_url()
        )), array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => 'CrawlGuard-WP/' . (defined('CRAWLGUARD_VERSION') ? CRAWLGUARD_VERSION : '1.0.0')
            ),
            'timeout' => $this->timeout,
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Site info request failed: ' . $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code === 200) {
            $data = json_decode($body, true);
            if ($data) {
                return array(
                    'success' => true,
                    'data' => $data
                );
            } else {
                return array(
                    'success' => false,
                    'message' => 'Invalid site info response format'
                );
            }
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch site info: ' . $status_code . ' - ' . $body
            );
        }
    }
    
    public function update_settings($settings) {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'message' => 'API key is required'
            );
        }
        
        $settings['site_url'] = home_url();
        
        $response = wp_remote_request($this->api_base_url . '/settings', array(
            'method' => 'PUT',
            'body' => json_encode($settings),
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => 'CrawlGuard-WP/' . CRAWLGUARD_VERSION
            ),
            'timeout' => $this->timeout
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            return array(
                'success' => true,
                'message' => 'Settings updated successfully'
            );
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to update settings: ' . $status_code
            );
        }
    }
    
    public function get_payment_history($limit = 50) {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'message' => 'API key is required'
            );
        }
        
        $query_params = array(
            'site_id' => $this->site_id,
            'limit' => min(max(1, intval($limit)), 1000) // Validate limit
        );
        
        $response = wp_remote_get($this->api_base_url . '/payments?' . http_build_query($query_params), array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
                'User-Agent' => 'CrawlGuard-WP/' . (defined('CRAWLGUARD_VERSION') ? CRAWLGUARD_VERSION : '1.0.0')
            ),
            'timeout' => $this->timeout,
            'sslverify' => true
        ));
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Payment history request failed: ' . $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        if ($status_code === 200) {
            $data = json_decode($body, true);
            if ($data) {
                return array(
                    'success' => true,
                    'data' => $data
                );
            } else {
                return array(
                    'success' => false,
                    'message' => 'Invalid payment history response format'
                );
            }
        } else {
            return array(
                'success' => false,
                'message' => 'Failed to fetch payment history: ' . $status_code . ' - ' . $body
            );
        }
    }
    
    // Add validation and utility methods
    public function validate_credentials() {
        $errors = array();
        
        if (empty($this->api_key)) {
            $errors[] = 'API key is missing';
        } elseif (!preg_match('/^cg_[a-z]+_[a-zA-Z0-9]+$/', $this->api_key)) {
            $errors[] = 'API key format is invalid';
        }
        
        if (empty($this->site_id)) {
            $errors[] = 'Site ID is missing';
        } elseif (!preg_match('/^site_[a-zA-Z0-9]+$/', $this->site_id)) {
            $errors[] = 'Site ID format is invalid';
        }
        
        if (empty($this->api_base_url)) {
            $errors[] = 'API base URL is missing';
        } elseif (!filter_var($this->api_base_url, FILTER_VALIDATE_URL)) {
            $errors[] = 'API base URL is not a valid URL';
        }
        
        return array(
            'valid' => empty($errors),
            'errors' => $errors
        );
    }
    
    public function get_api_status() {
        return array(
            'api_url' => $this->api_base_url,
            'has_api_key' => !empty($this->api_key),
            'has_site_id' => !empty($this->site_id),
            'timeout' => $this->timeout,
            'credentials_valid' => $this->validate_credentials()
        );
    }
}

/* Pay Per Crawl Admin JavaScript */
jQuery(document).ready(function($) {
    // Auto-refresh activity every 30 seconds
    setInterval(function() {
        refreshActivity();
    }, 30000);
    
    // Manual refresh button
    $('#ppc-refresh-activity').on('click', function() {
        var $btn = $(this);
        $btn.text('🔄 Refreshing...').prop('disabled', true);
        
        refreshActivity(function() {
            $btn.text('🔄 Refresh').prop('disabled', false);
        });
    });
    
    // Enable auto-scaling
    $('.ppc-enable-autoscale').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        $btn.text('Enabling...').prop('disabled', true);
        
        setTimeout(function() {
            $btn.text('✅ Enabled').addClass('button-primary').prop('disabled', false);
            $btn.closest('.ppc-tip').css('background', '#ecfdf5');
        }, 1500);
    });
    
    // Initialize dashboard
    initializeDashboard();
});

function refreshActivity(callback) {
    // AJAX call to refresh activity
    $.post(ajaxurl, {
        action: 'paypercrawl_bot_activity',
        _ajax_nonce: paypercrawl_ajax.nonce
    }, function(response) {
        if (response.success) {
            $('#ppc-bot-activity').html(response.data);
        }
        if (callback) callback();
    }).fail(function() {
        if (callback) callback();
    });
}

function initializeDashboard() {
    // Add smooth animations to stat cards
    $('.ppc-stat-card').each(function(index) {
        $(this).css('animation-delay', (index * 100) + 'ms');
        $(this).addClass('fade-in');
    });
}

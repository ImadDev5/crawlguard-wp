# Changelog

## Version 3.0.0 - 2025-07-24

### Major Release - Complete Rewrite
- **BREAKING:** Complete rewrite and rebranding from CrawlGuard WP to Pay Per Crawl
- **NEW:** 30+ enhanced AI bot signatures with company attribution
- **NEW:** Modern gradient dashboard with real-time updates
- **NEW:** Tiered bot detection system (Premium, Standard, Emerging, Research)
- **NEW:** Professional revenue tracking and analytics
- **NEW:** Non-blocking API integration with existing infrastructure
- **NEW:** Privacy-first architecture (MD5 hashes only)
- **NEW:** Responsive design optimized for all devices
- **IMPROVED:** Performance optimizations with async API calls
- **ENHANCED:** Bot detection accuracy with multiple detection methods

### Bot Detection Improvements
- Added OpenAI family: GPTBot, ChatGPT-User, OpenAI
- Added Anthropic family: CCBot, anthropic-ai, Claude-Web, ClaudeBot
- Added Google AI family: Google-Extended, GoogleOther, Bard, PaLM, Gemini
- Added Meta AI family: FacebookBot, Meta-ExternalAgent, Llama
- Added Microsoft AI family: BingBot, msnbot, CopilotBot
- Added emerging bots: PerplexityBot, YouBot, Bytespider, YandexBot

### Revenue System
- Tiered pricing: $0.02-$0.12 per detection
- Premium bots (OpenAI, Anthropic): $0.10-$0.12
- Standard bots (Google, Microsoft, Meta): $0.06-$0.08
- Emerging bots: $0.04-$0.05
- Research/scraper bots: $0.02-$0.03

### Technical Improvements
- Backend integration with existing Cloudflare infrastructure
- Standalone mode for independent operation
- Enhanced database schema with company attribution
- Real-time dashboard updates with Chart.js
- Professional admin interface with modern UI/UX
- AJAX-powered live activity feed
- Comprehensive setup checklist

## Version 2.0.0 - 2024-12-15
- Added basic monetization features
- Enhanced bot detection algorithms
- Improved admin dashboard

## Version 1.0.0 - 2024-06-01
- Initial release
- Basic bot detection functionality
- Simple logging system

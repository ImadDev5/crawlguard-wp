=== Pay Per Crawl ===
Contributors: paypercrawl
Tags: ai, bot detection, monetization, crawlers, revenue
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 3.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Turn every AI bot crawl into revenue with advanced bot detection and monetization.

== Description ==

**Pay Per Crawl** is the ultimate WordPress plugin for monetizing AI bot traffic on your website. Instead of just blocking bots, turn them into a revenue stream!

= Key Features =

* **30+ AI Bot Signatures** - Detects ChatGPT, Claude, Bard, Copilot, and more
* **Real-time Revenue Tracking** - See earnings from $0.02-$0.12 per bot visit
* **Professional Dashboard** - Modern analytics with Chart.js integration
* **Company Attribution** - Track which AI companies are crawling your content
* **Tiered Bot Detection** - Premium, Standard, Emerging, and Research tiers
* **Privacy-First** - Only sends MD5 hashes, never actual IP addresses
* **Non-blocking API** - Async calls won't slow down your site
* **Easy Setup** - Works out of the box with optional API integration

= Detected AI Bots Include =

**Premium Tier ($0.10-$0.12 per visit):**
* OpenAI (GPTBot, ChatGPT-User)
* Anthropic (CCBot, ClaudeBot)

**Standard Tier ($0.06-$0.08 per visit):**
* Google AI (Google-Extended, Bard, Gemini)
* Microsoft (BingBot, CopilotBot)
* Meta (FacebookBot, Llama)

**Emerging Tier ($0.04-$0.05 per visit):**
* Perplexity, You.com, ByteDance, Yandex

= How It Works =

1. **Install & Activate** - Plugin starts detecting bots immediately
2. **Monitor Dashboard** - See real-time bot detection and revenue
3. **Optional API Setup** - Connect to PayPerCrawl.tech for advanced features
4. **Earn Revenue** - Get paid for AI bot traffic automatically

= PayPerCrawl.tech Integration =

Connect to our premium service for:
* Higher revenue rates
* Advanced analytics
* API access
* Priority support
* Custom bot detection rules

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/pay-per-crawl/` directory
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Go to 'Pay Per Crawl' in your admin menu to view the dashboard
4. Optionally configure API settings for enhanced features

== Frequently Asked Questions ==

= Does this plugin slow down my website? =

No! All API calls are asynchronous and non-blocking. The bot detection happens in milliseconds without affecting your site's performance.

= What AI bots does it detect? =

Over 30 different AI bots including ChatGPT, Claude, Bard, Copilot, Perplexity, and many more. The list is constantly updated.

= How much can I earn? =

Revenue varies from $0.02-$0.12 per bot visit depending on the bot type. Premium bots like GPT-4 pay the highest rates.

= Is my data private? =

Yes! We only send MD5 hashes of IP addresses, never the actual IPs. User privacy is our top priority.

= Do I need a PayPerCrawl.tech account? =

No, the plugin works standalone. However, connecting to PayPerCrawl.tech unlocks premium features and higher revenue rates.

== Screenshots ==

1. Modern dashboard showing real-time bot detection and revenue
2. Comprehensive bot detection with 30+ AI signatures
3. Professional settings page with easy configuration
4. Revenue analytics and optimization tips
5. Live bot activity feed with company attribution

== Changelog ==

= 3.0.0 =
* Complete rewrite and rebranding from CrawlGuard WP
* 30+ enhanced bot signatures with company attribution
* Modern gradient dashboard with real-time updates
* Tiered bot detection (Premium, Standard, Emerging, Research)
* Professional revenue tracking and analytics
* Non-blocking API integration
* Privacy-first architecture
* Responsive design for all devices

= 2.0.0 =
* Added monetization features
* Enhanced bot detection
* Improved dashboard

= 1.0.0 =
* Initial release
* Basic bot detection
* Simple logging

== Upgrade Notice ==

= 3.0.0 =
Major update with complete rewrite, 30+ bot signatures, modern dashboard, and enhanced monetization features. Highly recommended upgrade.

== Privacy Policy ==

Pay Per Crawl respects your privacy:
* Only MD5 hashes of IP addresses are transmitted
* No personal user data is collected
* Bot detection data is stored locally in your WordPress database
* Optional API integration follows strict privacy guidelines

== Support ==

For support, documentation, and premium features, visit:
* Website: https://paypercrawl.tech
* Documentation: https://paypercrawl.tech/docs
* Support: https://paypercrawl.tech/support

== Credits ==

Developed by the PayPerCrawl.tech team with love for WordPress and AI monetization.
